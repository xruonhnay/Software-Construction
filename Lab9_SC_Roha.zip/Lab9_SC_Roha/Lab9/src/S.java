import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student",schema = "uni")
public class S {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Reg_no")
	private int id;
	
	@Column(name="name")
	private String Name;
	
	@Column(name="class")
	private String Class;
	

	
	public S() {
		
	}
	
	public S(String name, String Class) {
		super();
		
		Name = name;
		this.Class = Class;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getclass() {
		return Class;
	}

	public void setAddr(String Class) {
		this.Class = Class;
	}

	
	
	
}
