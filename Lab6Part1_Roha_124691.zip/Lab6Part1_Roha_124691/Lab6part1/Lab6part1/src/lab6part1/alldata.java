
package lab6part1;

import java.util.Scanner;
import java.util.*;

/**
 *
 * @author Roha
 */
public class alldata {
    int NumOfStudents=6; //6 total students
        int stats=3; //no of credentials

String[][] data= new String[NumOfStudents][stats]; //2 dimensional array having 6 rows and 3 coloumns
    public void MainData() //function to enter data 
    {  
        
        
        for (int i=0;i<NumOfStudents;i++)
        {   
            Scanner input1 = new Scanner(System.in); //taking input username
            System.out.println("Enter your name student!");
            data[i][0]=input1.nextLine(); //storing name in array at 0th index
            Scanner input2 = new Scanner(System.in);
            System.out.println("Enter your Registration Number!");
            String ch =input2.nextLine(); //storing regno in array at 1st index
            
            for (int y=0;y<i; y++)
            { while (ch.equals(data[y][1])) //condition to check if regno already exists
                    {   
                        System.out.println("Reg No exists Already, Enter your Registration Number!");
                        Scanner input = new Scanner(System.in); //if not unqiue then taking input
                        ch=input.nextLine();
                        
                    }
            data[i][1]=ch; //storing new input in array 1st index
            }
            data[i][1]=ch; //storing new input in array 1st index
            Scanner input3 = new Scanner(System.in); //taking CGPA input
            System.out.println("Enter your CGPA!");
            data[i][2]=input3.nextLine(); //storing CGPA at 2nd index of array
            String gg=data[i][2]; //stored in a string
            float cgpa=Float.parseFloat(gg); //converted string to float to be compared
            while(cgpa>4 || cgpa<=0) //checking croteria for invalidity
            { 
                System.out.println("Entered CGPA is not valid!");
                System.out.println("Enter CGPA again!");
                Scanner input4 = new Scanner(System.in); //taking CGPA input again
                System.out.println("Enter your CGPA!");
                data[i][2]=input4.nextLine(); //storing new input in array 2nd index
                String g=data[i][2]; //stored in a string
                cgpa=Float.parseFloat(g); //conversion to float
        }
        }//loop to print credentials of entered data students
        for (int k=0; k<NumOfStudents; k++)
        { System.out.println("Name is:"+ data[k][0]);
         System.out.println("Registration Number is:"+ data[k][1]);
         System.out.println("CGPA is:"+ data[k][2]);
        }
        
    }
    public void MinMaxAvg() //function for part1 B and C
    {
        float min=10;
        float max=0;
        float sum=0;
        for (int i=0; i<NumOfStudents;i++)
        { 
            if (Float.parseFloat(data[i][2])<min) //checking if CGPA is less than minimum set
            {   
                min=Float.parseFloat(data[i][2]); //stored CGPA in INT min
            }
            if (Float.parseFloat(data[i][2])>max) //checking if CGPA is greater than maximun set
            {   
                max=Float.parseFloat(data[i][2]); //stored CGPA in INT max
            }
            sum+=Float.parseFloat(data[i][2]); //taking sum of all CGPAs of students in data
    }
        System.out.println("Mimimun CGPA is:"+ min);//printing minimun CGPA of class
        System.out.println("Maximum CGPA is:"+ max); //printing maximum CGPA of class
        System.out.println("Average CGPA is:"+ sum/NumOfStudents); //printing average CGPA of class
        
        for (int h=0;h<NumOfStudents;h++) //loop to traverse array
        {
            if (Float.parseFloat(data[h][2])<sum/NumOfStudents) //checking if CGPA of some student is less than average of class
            {
                System.out.println("Student  "+ data[h][0]+" has CGPA: "+ data[h][2]+" which is less than average");
            }
        }
}
    public void SearchRank() //function for part1 D
    {
        float[] RankData=new float[6]; //made a rank to store names sorted by CGPA
        System.out.println("Enter 1 to search by Name");
        System.out.println("Enter 2 to search by Registration Number");
        Scanner inp = new Scanner(System.in);
        String search= inp.nextLine();  //taking input var to give a choice
            for( int j=0;j<NumOfStudents;j++)
        {
            RankData[j]= Float.parseFloat(data[j][2]); //stored CGPA in Rank array
        }
            Arrays.sort(RankData); //sorted thearray w.r.t CGPA in ascending order
        
        int choice= Integer.parseInt(search); //converted entered choice in INT
        
        if (choice==1) //if by name
        {
            System.out.println("Enter the Name of Student");
            Scanner inp1 = new Scanner(System.in); //enter student name
            String nam=inp1.nextLine(); //stored input
             for (int u=0; u<NumOfStudents;u++)
             { 
        	if (nam.equals(data[u][0])) //if name exists in previous data
        {          System.out.println("Name Exists in Data!");
        	   System.out.println("CGPA is "+data[u][2]);
        	   for(int f = 0;f<RankData.length;f++) //loop to traverse CGPA array
                   {
        		if(Float.parseFloat(data[u][2]) == RankData[f]) //if CGPA exists in data of students
                        {
            		System.out.println("Rank is: "+ (RankData.length-f)+" out of "+RankData.length); //print RANK w.r.t CGPA of student
            	        }
        		
        	    }
        	break;
        }
               else {
             System.out.println("Name doesn't exist");
                     }
            }
        }
        else if(choice==2) //if entered choice is for REG NO
        {
            System.out.println("Enter the Registration Number of Student");
            Scanner inp2 = new Scanner(System.in); //take input
            String reg=inp2.nextLine(); //stored in string
            for (int u=0; u<NumOfStudents;u++) //loop to travserse array
            { 
            	
            	if (reg.equals(data[u][1])) //if enreted REGNO is in previous entered data
                { 
        	   System.out.println("Reg No Exists in Data!");
                   System.out.println("CGPA is "+data[u][2]); //pinting CGPA
        	   for(int f = 0;f<RankData.length;f++) //loop to traverse RANK array
                   {
        		
        		if(Float.parseFloat(data[u][2]) == RankData[f]) { //if CGPA matches
            		System.out.println("Rank is: "+ (RankData.length-f)+" out of "+RankData.length); //print rank
            	                                                        }
        		
        	       }
          break;
        }
              else {
             System.out.println("Reg No doesn't exist");
                    }
            }
        
        }  
    }
    
    
}