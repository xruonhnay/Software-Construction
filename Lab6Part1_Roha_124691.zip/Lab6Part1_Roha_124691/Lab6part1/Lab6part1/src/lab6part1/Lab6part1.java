
package lab6part1;
import java.util.Scanner;


/**
 *
 * @author Roha
 */
public class Lab6part1 {

    public static void main(String[] args) {
       alldata obj= new alldata(); //made the object
      //called all methods
       obj.MainData();
      obj.MinMaxAvg();
       obj.SearchRank();
      
       
       
        
    }
}
    

