
package lab6part2;
import java.sql.*; //package for importing SQL connections
import java.util.*; 

/**
 *
 * @author Roha
 */
public class Functions {
    public void DisplayAll() //method to display all databse records
    {
        try{  
Class driver= Class.forName("com.mysql.jdbc.Driver");  //made the driver class avaibale on website
Driver dr = (Driver) driver.newInstance(); //created a driver instance
DriverManager.registerDriver(dr); //registered the driver in driver manager
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/universitydata","root","bitch135");   //made the connection of JDBC with MYSQL providing credentials

Statement stmt=con.createStatement(); //created a sql statement 
ResultSet rs=stmt.executeQuery("select * from student");  //stored the result of mysql query 
System.out.println("ID  RegNo   Name  Class  Section   Contact        Address");
while(rs.next())  //printing the databse records
System.out.println(rs.getInt(1)+"   "+rs.getString(2)+"  "+rs.getString(3)+"   "+rs.getString(4)+"    "+rs.getString(5)+"       "+rs.getString(6)+"     "+rs.getString(7));  
con.close();  //connection of database closed
}
        catch(Exception e) //if condition not fulfilled then print an exception
{ System.out.println(e);}
    
    }
    
    public void DeleteRecord() //method to delete a user entered record from database
    {
        try{  
Class driver= Class.forName("com.mysql.jdbc.Driver");  //made the driver class avaibale on website
Driver dr = (Driver) driver.newInstance(); //created a driver instance
DriverManager.registerDriver(dr); //registered the driver in driver manager
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/universitydata","root","bitch135");  //made the connection of JDBC with MYSQL providing credentials

System.out.println("Enter the Name of student to be deleted");
Scanner input = new Scanner(System.in); //taking input from user
 String data=input.nextLine(); //converting into string to be given to method to compare in database

 String sql = "DELETE FROM student WHERE Name=?"; //created a SQL statement and stored in a string
 
PreparedStatement statement = con.prepareStatement(sql); //statement instance prepared
statement.setString(1, data); //string set to be checked in database
 
int rowsDeleted = statement.executeUpdate(); //stored number of rows delted in an integer variable
if (rowsDeleted > 0) //checked if any users are deleted
{
    System.out.println("A user was deleted successfully!");
}
con.close(); //closed connection of JDBC and MYSQL 
}
        catch(Exception e) //if condition not fulfilled then print an exception
{ System.out.println(e);}
    
    }
    public void SearchRecord()
    {
        try{  
Class driver= Class.forName("com.mysql.jdbc.Driver"); //made the driver class avaibale on website
Driver dr = (Driver) driver.newInstance(); //created a driver instance
DriverManager.registerDriver(dr); //registered the driver in driver manager
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/universitydata","root","bitch135");  //made the connection of JDBC with MYSQL providing credentials
 
System.out.println("Enter the Name of student to be deleted");
Scanner input = new Scanner(System.in); //taking input from user
 String data=input.nextLine();

 String sql = "SELECT * FROM student WHERE Name=?"; //created a SQL statement and stored in a string
 
PreparedStatement statement = con.prepareStatement(sql); //statement instance prepared
statement.setString(1, data); //string set to be checked in database
 
ResultSet rs= statement.executeQuery(); //stored the result in a result variavle
System.out.println("These are the credentials of your entered user");
while(rs.next())  //printing the credentials of entered name
System.out.println(rs.getInt(1)+"   "+rs.getString(2)+"  "+rs.getString(3)+"   "+rs.getString(4)+"    "+rs.getString(5)+"       "+rs.getString(6)+"     "+rs.getString(7)); 

con.close();  //closed connection of JDBC and MYSQL 
}
        catch(Exception e) //if condition not fulfilled then print an exception
{ System.out.println(e);}
    
    }
}
