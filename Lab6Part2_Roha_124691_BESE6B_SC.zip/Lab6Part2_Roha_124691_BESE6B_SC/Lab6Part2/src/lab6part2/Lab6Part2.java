package lab6part2;
import java.sql.*;
import java.util.*; 
/**
 *
 * @author Roha
 */
public class Lab6Part2  //mainclass
{

    public static void main(String[] args) {
        Functions obj= new Functions(); //created instance
        while(true) //infinte loop to ask choice again after every result
        {
        System.out.println("HELLO USER!");
        System.out.println("Enter 1 to DISPLAY all records in database!");
        System.out.println("Enter 2 to DELETE a specific STUDENT from database!");
        System.out.println("Enter 3 to VIEW a specific STUDENT from database!");
        
        Scanner inp = new Scanner(System.in);
        String search= inp.nextLine();  //taking input var to give a choice
        int choice= Integer.parseInt(search); //convetred into integer to check condition
       
       
        if (choice==1)
        {
            obj.DisplayAll(); //called the method to display all students' records
        }
        else if (choice==2) 
        {
            obj.DeleteRecord(); //called the method to delete an entered choice
        }        
        else if(choice==3)
        { 
            obj.SearchRecord(); //called the method to search selected user
        }
        else
        {
            System.out.println("Not a valid choice!");
        }
       
    }}
    
    
}
