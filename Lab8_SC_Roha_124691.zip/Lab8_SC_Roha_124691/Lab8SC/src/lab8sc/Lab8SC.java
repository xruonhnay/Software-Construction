package lab8sc;
import java.sql.*; //package for importing SQL connections
import java.util.*; 

/**
 *
 * @author Roha
 */
public class Lab8SC {

    public static void main(String[] args) {
Data Obj= new Data();
//Obj.AddData();//called the method to add 5000 records
    
    //Obj.AddData2();
    Obj.AddData3();
    }
    
}
