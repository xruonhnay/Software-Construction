package lab8sc;
import java.sql.*; //package for importing SQL connections
import java.util.*; 
/**
 *
 * @author Roha
 */
public class Data {
    public void AddData() //method using statement class
    {
     try{  
Class driver= Class.forName("com.mysql.jdbc.Driver");  //made the driver class avaibale on website
Driver dr = (Driver) driver.newInstance(); //created a driver instance
DriverManager.registerDriver(dr); //registered the driver in driver manager
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/lab8database","root","bitch135");  //made the connection of JDBC with MYSQL providing credentials
Statement st = con.createStatement(); //statement instance prepared
con.setAutoCommit(false);
for(int i=5050;i<10050;i++)
 {
 String sql = "INSERT INTO student(Name,RegNumber,Semester,Address) VALUES('Roha"+i+"',"+i+",'5th Semester','HouseNumber"+i+"')"; //inserting into coulumns the values
st.executeUpdate(sql);
 }
con.commit();
con.close(); //closed connection of JDBC and MYSQL 
}
       catch(Exception e) //if condition not fulfilled then print an exception
{ System.out.println(e);}
    
    }
    public void AddData2() //using prepared statement class
    {
        try{  
Class driver= Class.forName("com.mysql.jdbc.Driver");  //made the driver class avaibale on website
Driver dr = (Driver) driver.newInstance(); //created a driver instance
DriverManager.registerDriver(dr); //registered the driver in driver manager
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/lab8database","root","bitch135");  //made the connection of JDBC with MYSQL providing credentials
Statement st = con.createStatement(); //statement instance prepared
con.setAutoCommit(false); 

String Name="Roha";
String RegNum;
String f=":";
String Semester="5th Sem";
String Add="House Number:";
String Address;

for(int i=20001;i<20501;i++)
 {
     Address=Add+i; 
     RegNum=f +i;
 String sql = "INSERT INTO student(Name,RegNumber,Semester,Address) VALUES(?,?,?,?)"; //inserting into coulumns the values
 PreparedStatement stm=con.prepareStatement(sql);
 stm.setString(1,Name);
 stm.setString(2,RegNum);
 stm.setString(3,Semester);
 stm.setString(4,Address);
 
stm.execute();
 }
con.commit();

con.close(); //closed connection of JDBC and MYSQL 
}
       catch(Exception e) //if condition not fulfilled then print an exception
{ System.out.println(e);}
    }
    public void AddData3() //method using batch update
    {
    try{  
Class driver= Class.forName("com.mysql.jdbc.Driver");  //made the driver class avaibale on website
Driver dr = (Driver) driver.newInstance(); //created a driver instance
DriverManager.registerDriver(dr); //registered the driver in driver manager
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/lab8database","root","bitch135");  //made the connection of JDBC with MYSQL providing credentials
Statement st = con.createStatement(); //statement instance prepared
con.setAutoCommit(false);
for(int i=30000;i<30500;i++)
 {
 String sql = "INSERT INTO student(Name,RegNumber,Semester,Address) VALUES('Roha"+i+"',"+i+",'5th Semester','HouseNumber"+i+"')"; //inserting into coulumns the values
st.addBatch(sql);
st.executeBatch();
 }
con.commit();
con.close(); //closed connection of JDBC and MYSQL 
}
       catch(Exception e) //if condition not fulfilled then print an exception
{ System.out.println(e);}
    }
    
}
